package collection.src.array_list;

import java.util.LinkedList;

public class listIterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LinkedList<Integer> l=new LinkedList<Integer>();
l.add(6);
l.add(61);
l.add(62);
l.add(63);
l.add(64);
l.add(65);
l.add(66);

l.add(66);
l.add(67);
l.add(68);


l.add(69);
System.out.println(l);
listIterator it=(listIterator) l.listIterator();



	}
	}
