package collection.src.array_list;

import java.util.*;

public class arraylist_synchronized {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Integer> i=new ArrayList<Integer>();
List l=Collections.synchronizedList(i);

{
};
	}

}
