package collection.src.array_list.set;

import java.util.TreeSet;

public class treeset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         TreeSet<Integer> i=new TreeSet<>();
         TreeSet<Character> j=new TreeSet<>();
         i.add(67);
         i.add(2);
         i.add(23);
         i.add(24);
         i.add(21);
         i.add(12);
         i.add(22);
         i.add(20);
         i.add(26);
         i.add(02);
         i.add(62);
         //j.add(null);
         i.add(100);
        // j.addAll(i);
         j.add('C');
         j.add('D');
         j.add('E');
         j.add('W');
         
         System.out.println(j+"\n");

	}

}
